module.exports = {
  MONGOBD_URL: "mongodb+srv://vasu_mukku:mohan@vasu-01.grbhl9w.mongodb.net/?retryWrites=true&w=majority",
  JWT_SECRET: "fhgsefuilhgvsdfhvldgvigdfbkuvgdyukbyudglvsg",
};
